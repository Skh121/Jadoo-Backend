package com.example.tourtravel.Controller;


import com.example.tourtravel.Entity.Choices;

import com.example.tourtravel.Pojo.ChoicePojo;

import com.example.tourtravel.Service.ChoiceService;

import com.example.tourtravel.shared.GlobalApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/choices")
@RequiredArgsConstructor


public class ChoiceController {

    private final ChoiceService choiceService;


    @GetMapping("/get")
    public GlobalApiResponse<List<Choices>> getData() {
        List<Choices> choices = choiceService.getAll();
        return GlobalApiResponse.<List<Choices>>builder()
                .data(choices)
                .statusCode(200)
                .message("Data retrieved successfully!")
                .build();
    }

    @PostMapping("/save")
    public GlobalApiResponse<Void> save(@RequestBody ChoicePojo choicePojo) {
        choiceService.addChoice(choicePojo);
        return GlobalApiResponse.<Void>builder()
                .statusCode(201)
                .message("choice saved successfully!")
                .build();
    }

    @GetMapping("/get/{id}")
    public GlobalApiResponse<Choices> getData(@PathVariable Long id) {
        Optional<Choices> choices = choiceService.findById(id.intValue());
        if (choices.isPresent()) {
            return GlobalApiResponse.<Choices>builder()
                    .data(choices.get())
                    .statusCode(200)
                    .message("Building retrieved successfully!")
                    .build();
        } else {
            return GlobalApiResponse.<Choices>builder()
                    .statusCode(404)
                    .message("Building not found!")
                    .build();
        }
    }
    @PutMapping("/update/{id}")
    public GlobalApiResponse<Void> update(@PathVariable Long id, @RequestBody ChoicePojo choicePojo) {
        if (!choiceService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        // Update the existing ground with the provided ID
        choiceService.updateData(id, choicePojo);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " updated successfully")
                .build();
    }

    @DeleteMapping("/delete/{id}")
    public GlobalApiResponse<Void> delete(@PathVariable Long id) {
        if (!choiceService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        choiceService.deleteById(id);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " deleted successfully")
                .build();
    }

}
