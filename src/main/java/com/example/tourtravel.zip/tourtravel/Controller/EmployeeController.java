package com.example.tourtravel.Controller;


import com.example.tourtravel.Entity.Employee;
import com.example.tourtravel.Pojo.EmployeePojo;
import com.example.tourtravel.Service.EmployeeService;
import com.example.tourtravel.shared.GlobalApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@RestController
@RequestMapping("/employee")

public class EmployeeController {
    private final EmployeeService employeeService;

    @GetMapping("/get")
    public GlobalApiResponse<List<Employee>> getData() {
        List<Employee> Employees =employeeService .getAll();
        return GlobalApiResponse.<List<Employee>>builder()
                .data(Employees)
                .statusCode(200)
                .message("Data retrieved successfully!")
                .build();
    }

    @PostMapping("/save")
    public GlobalApiResponse<Void> save(@RequestBody EmployeePojo employeePojo) {
        employeeService.addEmployee(employeePojo);
        return GlobalApiResponse.<Void>builder()
                .statusCode(201)
                .message("Building saved successfully!")
                .build();
    }

    @GetMapping("/get/{id}")
    public GlobalApiResponse<Employee> getData(@PathVariable Integer id) {
        Optional<Employee> employee = employeeService.findById(id);
        if (employee.isPresent()) {
            return GlobalApiResponse.<Employee>builder()
                    .data(employee.get())
                    .statusCode(200)
                    .message("Building retrieved successfully!")
                    .build();
        } else {
            return GlobalApiResponse.<Employee>builder()
                    .statusCode(404)
                    .message("Building not found!")
                    .build();
        }
    }
    @PutMapping("/update/{id}")
    public GlobalApiResponse<Void> update(@PathVariable Integer id, @RequestBody EmployeePojo employeePojo) {
        if (!employeeService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        // Update the existing ground with the provided ID
        employeeService.updateData(id, employeePojo);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " updated successfully")
                .build();
    }

    @DeleteMapping("/delete/{id}")
    public GlobalApiResponse<Void> delete(@PathVariable Integer id) {
        if (!employeeService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        employeeService.deleteById(id);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " deleted successfully")
                .build();
    }
}
