package com.example.tourtravel.Controller;

import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Entity.Hotels;
import com.example.tourtravel.Pojo.CompanyPojo;
import com.example.tourtravel.Pojo.HotelPojo;
import com.example.tourtravel.Service.CompanyService;
import com.example.tourtravel.Service.HotelService;
import com.example.tourtravel.shared.GlobalApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/hotels")
@RequiredArgsConstructor

public class HotelController {

    @Autowired

    private final HotelService hotelService;


    @GetMapping("/get")
    public GlobalApiResponse<List<Hotels>> getData() {
        List<Hotels> hotels = hotelService.getAll();
        return GlobalApiResponse.<List<Hotels>>builder()
                .data(hotels)
                .statusCode(200)
                .message("Data retrieved successfully!")
                .build();
    }

    @PostMapping("/save")
    public GlobalApiResponse<Void> save(@RequestBody HotelPojo hotelPojo) {
        hotelService.addHotel(hotelPojo);
        return GlobalApiResponse.<Void>builder()
                .statusCode(201)
                .message("Building saved successfully!")
                .build();
    }

    @GetMapping("/get/{id}")
    public GlobalApiResponse<Hotels> getData(@PathVariable Long id) {
        Optional<Hotels> hotels = hotelService.findById(id);
        if (hotels.isPresent()) {
            return GlobalApiResponse.<Hotels>builder()
                    .data(hotels.get())
                    .statusCode(200)
                    .message("Building retrieved successfully!")
                    .build();
        } else {
            return GlobalApiResponse.<Hotels>builder()
                    .statusCode(404)
                    .message("Building not found!")
                    .build();
        }
    }
    @PutMapping("/update/{id}")
    public GlobalApiResponse<Void> update(@PathVariable Long id, @RequestBody HotelPojo hotelPojo) {
        if (!hotelService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        // Update the existing ground with the provided ID
        hotelService.updateData(id, hotelPojo);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " updated successfully")
                .build();
    }

    @DeleteMapping("/delete/{id}")
    public GlobalApiResponse<Void> delete(@PathVariable Long id) {
        if (!hotelService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        hotelService.deleteById(id);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " deleted successfully")
                .build();
    }


}
