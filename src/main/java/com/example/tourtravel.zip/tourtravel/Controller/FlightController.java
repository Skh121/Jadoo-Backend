package com.example.tourtravel.Controller;


import com.example.tourtravel.Entity.Flights;
import com.example.tourtravel.Pojo.FlightPojo;
import com.example.tourtravel.Service.FlightService;
import com.example.tourtravel.shared.GlobalApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@RestController
@RequestMapping("/flights")

public class FlightController {

        private final FlightService flightService;


        @GetMapping("/get")
        public GlobalApiResponse<List<Flights>> getData() {
            List<Flights> flightsList = flightService.getAll();
            return GlobalApiResponse.<List<Flights>>builder()
                    .data(flightsList)
                    .statusCode(200)
                    .message("Data retrieved successfully!")
                    .build();
        }

        @PostMapping("/save")
        public GlobalApiResponse<Void> save(@RequestBody FlightPojo flightPojo) {
            flightService.addFlights(flightPojo);
            return GlobalApiResponse.<Void>builder()
                    .statusCode(201)
                    .message("Building saved successfully!")
                    .build();
        }

        @GetMapping("/get/{id}")
        public GlobalApiResponse<Flights> getData(@PathVariable Long id) {
            Optional<Flights> company = flightService.findById(id);
            if (company.isPresent()) {
                return GlobalApiResponse.<Flights>builder()
                        .data(company.get())
                        .statusCode(200)
                        .message("Building retrieved successfully!")
                        .build();
            } else {
                return GlobalApiResponse.<Flights>builder()
                        .statusCode(404)
                        .message("Building not found!")
                        .build();
            }
        }
        @PutMapping("/update/{id}")
        public GlobalApiResponse<Void> update(@PathVariable Long id, @RequestBody FlightPojo flightPojo) {
            if (!flightService.existsById(id)) {
                return GlobalApiResponse.<Void>builder()
                        .statusCode(404)
                        .message("Ground with ID " + id + " not found")
                        .build();
            }

            // Update the existing ground with the provided ID
            flightService.updateData(id, flightPojo);

            return GlobalApiResponse.<Void>builder()
                    .statusCode(200)
                    .message("Ground with ID " + id + " updated successfully")
                    .build();
        }

        @DeleteMapping("/delete/{id}")
        public GlobalApiResponse<Void> delete(@PathVariable Long id) {
            if (!flightService.existsById(id)) {
                return GlobalApiResponse.<Void>builder()
                        .statusCode(404)
                        .message("Ground with ID " + id + " not found")
                        .build();
            }

            flightService.deleteById(id);

            return GlobalApiResponse.<Void>builder()
                    .statusCode(200)
                    .message("Ground with ID " + id + " deleted successfully")
                    .build();
        }

    }


