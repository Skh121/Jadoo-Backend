package com.example.tourtravel.Controller;

import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Entity.Orders;
import com.example.tourtravel.Pojo.CompanyPojo;
import com.example.tourtravel.Pojo.OrderPojo;
import com.example.tourtravel.Service.CompanyService;
import com.example.tourtravel.Service.OrderService;
import com.example.tourtravel.shared.GlobalApiResponse;
import lombok.RequiredArgsConstructor;
import org.hibernate.query.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/order")
@RequiredArgsConstructor

public class OrderController {

    @Autowired

    private final OrderService orderService;


    @GetMapping("/get")
    public GlobalApiResponse<List<Orders>> getData() {
        List<Orders> orders = orderService.getAll();
        return GlobalApiResponse.<List<Orders>>builder()
                .data(orders)
                .statusCode(200)
                .message("Data retrieved successfully!")
                .build();
    }

    @PostMapping("/save")
    public GlobalApiResponse<Void> save(@RequestBody OrderPojo orderPojo) {
        orderService.addOrder(orderPojo);
        return GlobalApiResponse.<Void>builder()
                .statusCode(201)
                .message("Building saved successfully!")
                .build();
    }

    @GetMapping("/get/{id}")
    public GlobalApiResponse<Orders> getData(@PathVariable Long id) {
        Optional<Orders> orders = orderService.findById(id.intValue());
        if (orders.isPresent()) {
            return GlobalApiResponse.<Orders>builder()
                    .data(orders.get())
                    .statusCode(200)
                    .message("Building retrieved successfully!")
                    .build();
        } else {
            return GlobalApiResponse.<Orders>builder()
                    .statusCode(404)
                    .message("Building not found!")
                    .build();
        }
    }
    @PutMapping("/update/{id}")
    public GlobalApiResponse<Void> update(@PathVariable Long id, @RequestBody OrderPojo orderPojo) {
        if (!orderService.existsById(id.intValue())) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        // Update the existing ground with the provided ID
        orderService.updateData(id.intValue(), orderPojo);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " updated successfully")
                .build();
    }

    @DeleteMapping("/delete/{id}")
    public GlobalApiResponse<Void> delete(@PathVariable Integer id) {
        if (!orderService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        orderService.deleteById(id);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " deleted successfully")
                .build();
    }

}
