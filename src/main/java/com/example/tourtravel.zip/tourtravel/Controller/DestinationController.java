package com.example.tourtravel.Controller;



import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Entity.Destinations;
import com.example.tourtravel.Pojo.CompanyPojo;

import com.example.tourtravel.Pojo.DestinationPojo;
import com.example.tourtravel.Service.DestinationService;
import com.example.tourtravel.shared.GlobalApiResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/destination")
@RequiredArgsConstructor


public class DestinationController {

    private final DestinationService destinationService;


    @GetMapping("/get")
    public GlobalApiResponse<List<Destinations>> getData() {
        List<Destinations> destinations = destinationService.getAll();
        return GlobalApiResponse.<List<Destinations>>builder()
                .data(destinations)
                .statusCode(200)
                .message("Data retrieved successfully!")
                .build();
    }

    @PostMapping("/save")
    public GlobalApiResponse<Void> save(@RequestBody DestinationPojo destinationPojo) {
        destinationService.addDestination(destinationPojo);
        return GlobalApiResponse.<Void>builder()
                .statusCode(201)
                .message("Building saved successfully!")
                .build();
    }

    @GetMapping("/get/{id}")
    public GlobalApiResponse<Destinations> getData(@PathVariable Long id) {
        Optional<Destinations> destinations = destinationService.findById(id);
        if (destinations.isPresent()) {
            return GlobalApiResponse.<Destinations>builder()
                    .data(destinations.get())
                    .statusCode(200)
                    .message("Building retrieved successfully!")
                    .build();
        } else {
            return GlobalApiResponse.<Destinations>builder()
                    .statusCode(404)
                    .message("Building not found!")
                    .build();
        }
    }
    @PutMapping("/update/{id}")
    public GlobalApiResponse<Void> update(@PathVariable Long id, @RequestBody DestinationPojo destinationPojo) {
        if (!destinationService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        // Update the existing ground with the provided ID
        destinationService.updateData(id,  destinationPojo);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("Ground with ID " + id + " updated successfully")
                .build();
    }

    @DeleteMapping("/delete/{id}")
    public GlobalApiResponse<Void> delete(@PathVariable Long id) {
        if (!destinationService.existsById(id)) {
            return GlobalApiResponse.<Void>builder()
                    .statusCode(404)
                    .message("Ground with ID " + id + " not found")
                    .build();
        }

        destinationService.deleteById(id);

        return GlobalApiResponse.<Void>builder()
                .statusCode(200)
                .message("destination with ID " + id + " deleted successfully")
                .build();
    }

}
