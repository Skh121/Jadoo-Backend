package com.example.tourtravel.Controller;

import com.example.tourtravel.Entity.Customer;
import com.example.tourtravel.Entity.Role;
import com.example.tourtravel.Pojo.AuthResponsePojo;
import com.example.tourtravel.Pojo.CustomerPojo;
import com.example.tourtravel.Repo.CustomerRepo;
import com.example.tourtravel.Repo.RoleRepository;
import com.example.tourtravel.security.JwtGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private AuthenticationManager authenticationManager;
    private CustomerRepo customerRepo;
    private RoleRepository roleRepository;
    private PasswordEncoder passwordEncoder;
    private JwtGenerator jwtGenerator;

    public AuthController(AuthenticationManager authenticationManager, CustomerRepo customerRepo, RoleRepository roleRepository, PasswordEncoder passwordEncoder, JwtGenerator jwtGenerator) {
        this.authenticationManager = authenticationManager;
        this.customerRepo = customerRepo;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtGenerator = jwtGenerator;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponsePojo> login(@RequestBody CustomerPojo loginPojo){
        Authentication authentication=authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginPojo.getUsername(),
                loginPojo.getPassword()));
        SecurityContextHolder.getContext()
                .setAuthentication(authentication);
        String token=jwtGenerator.generateToken(authentication);
    return new ResponseEntity<>(new AuthResponsePojo(token), HttpStatus.OK);
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody CustomerPojo registerPojo){
        if(customerRepo.existsByUsername(registerPojo.getUsername())){
            return new ResponseEntity<>("username is taken", HttpStatus.BAD_REQUEST);
        }
        Customer user=new Customer();
        user.setUsername(registerPojo.getUsername());
        user.setPassword(passwordEncoder.encode(registerPojo.getPassword()));
        user.setId(registerPojo.getId());
        user.setName(registerPojo.getName());
        user.setLocation(registerPojo.getLocation());
//        customer.setTelNo(customerPojo.getTelNo());
        user.setContactEmail(registerPojo.getContactEmail());

//        Role roles=roleRepository.findByName("USER").get();
//        user.setRoles(Collections.singletonList(roles));
        customerRepo.save(user);
        return new ResponseEntity<>("User registered success",HttpStatus.OK);
    }

}
