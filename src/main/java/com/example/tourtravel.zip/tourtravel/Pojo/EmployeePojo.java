package com.example.tourtravel.Pojo;
import com.example.tourtravel.Entity.Company;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class EmployeePojo {
    private Integer id;
    private Company company;

    private String name;
private String location;

    private String contactEmail;

//    private Integer telNo;
}
