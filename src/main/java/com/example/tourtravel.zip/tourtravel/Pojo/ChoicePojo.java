package com.example.tourtravel.Pojo;

import com.example.tourtravel.Entity.Destinations;
import jakarta.persistence.Column;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor

public class ChoicePojo {
    private Long id;
    private String choiceName;

    private List<Destinations> destinationsList;
}
