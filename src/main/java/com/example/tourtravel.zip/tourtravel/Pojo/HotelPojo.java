package com.example.tourtravel.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@NoArgsConstructor
@AllArgsConstructor

public class HotelPojo {
    private Long id;
    private LocalDate date;
    private Long price;
    private String location;
    private String hotel;
    private Long noOfDays;
}
