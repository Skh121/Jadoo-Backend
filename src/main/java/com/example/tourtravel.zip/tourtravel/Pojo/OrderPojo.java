package com.example.tourtravel.Pojo;

import com.example.tourtravel.Entity.Customer;
import com.example.tourtravel.Entity.Destinations;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderPojo {
    private Integer id;
    private Destinations destinations;
    private Customer customer;
    private LocalDate orderDate;

}
