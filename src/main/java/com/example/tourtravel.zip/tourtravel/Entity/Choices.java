package com.example.tourtravel.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table
@Data
public class Choices {
    @Id
    private Long id;
    @Column
    private String choiceName;
    @OneToMany
    private List<Destinations> destinationsList;
}
