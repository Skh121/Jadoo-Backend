package com.example.tourtravel.Entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;

@Table
@Entity

@Getter

@Setter


public class Orders {
    @Id
    private Integer id;


    @ManyToOne
    private Customer customer;

    @Column(
            name = "Date"
    )
    private LocalDate orderDate;
    @ManyToOne
    private  Destinations destinations;


}
