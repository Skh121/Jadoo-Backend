package com.example.tourtravel.Entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Table
@Entity
@Setter
@Getter
public class Customer {

    @Id
    private Integer id;


    @Column(
            name = "Name"
    )
    private String name;
    @Column(
            name = "Location"
    )
    private String location;
    @Column(
            name = "Contact Email"
    )
    private String contactEmail;
    @Column
    private String username;
    @Column
    private String password;
//    @Column(
//            name = "Tel Number"
//    )
//    private Integer telNo;
@ManyToMany
@JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id")
)
private List<Role> roles = new ArrayList<>();

}
