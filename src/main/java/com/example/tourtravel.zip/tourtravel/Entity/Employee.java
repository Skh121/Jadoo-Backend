package com.example.tourtravel.Entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Table
@Entity
@Setter

@Getter
public class Employee {
    @Id
    private Integer id;
    @ManyToOne
    private Company company;
    @Column(
            name = "Name"
    )
    private String name;
    @Column(
            name = "Location"
    )
    private String location;
    @Column(
            name = "Contact Email"
    )
    private String contactEmail;
//    @Column(
//            name = "Tel Number"
//    )
//    private Integer telNo;
}
