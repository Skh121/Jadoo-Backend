package com.example.tourtravel.Service;

import com.example.tourtravel.Entity.Choices;
import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Pojo.ChoicePojo;
import com.example.tourtravel.Pojo.CompanyPojo;

import java.util.List;
import java.util.Optional;

public interface ChoiceService {
    void addChoice(ChoicePojo choicePojo);

    void deleteById(Long id);

    List<Choices> getAll();

    Optional<Choices> findById(Integer id);
    void updateData(Long id, ChoicePojo choicePojo);
    boolean existsById(Long id);
}
