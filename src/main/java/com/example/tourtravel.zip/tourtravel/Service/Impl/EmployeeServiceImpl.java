package com.example.tourtravel.Service.Impl;


import com.example.tourtravel.Entity.Employee;
import com.example.tourtravel.Pojo.EmployeePojo;
import com.example.tourtravel.Repo.EmployeeRepo;
import com.example.tourtravel.Service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service

public class EmployeeServiceImpl implements EmployeeService {
    private final EmployeeRepo employeeRepo;
    @Override
    public void addEmployee(EmployeePojo employeePojo) {
        Employee employee = new Employee();
        employee.setId(employeePojo.getId());
        employee.setName(employeePojo.getName());
        employee.setLocation(employeePojo.getLocation());
        employee.setCompany(employeePojo.getCompany());
//        employee.setTelNo(employeePojo.getTelNo());
        employee.setContactEmail(employeePojo.getContactEmail());
        this.employeeRepo.save(employee);
    }

    @Override
    public void updateData(Integer id, EmployeePojo employeePojo) {
        Optional<Employee> employeeOptional = employeeRepo.findById(id);
        if (employeeOptional.isPresent()) {
            Employee existingEmployee = employeeOptional.get();
            updateBuildingProperties(existingEmployee, employeePojo);
            employeeRepo.save(existingEmployee); // Save the updated student
        } else {
            throw new IllegalArgumentException("Booking with ID " + id + " not found");
        }

    }
    private void updateBuildingProperties(Employee employee, EmployeePojo employeePojo) {
        employee.setId(employeePojo.getId());
        employee.setName(employeePojo.getName());
        employee.setLocation(employeePojo.getLocation());
//        employee.setTelNo(employeePojo.getTelNo());
        employee.setContactEmail(employeePojo.getContactEmail());
        employee.setCompany(employeePojo.getCompany());
        this.employeeRepo.save(employee);

    }



    @Override
    public void deleteById(Integer id) {
        this.employeeRepo.deleteById(id);

    }

    @Override
    public List<Employee> getAll() {
        return this.employeeRepo.findAll();
    }

    @Override
    public Optional<Employee> findById(Integer id) {
        return this.employeeRepo.findById(id);
    }



    @Override
    public boolean existsById(Integer id) {
        return this.employeeRepo.existsById(id);
    }
}
