package com.example.tourtravel.Service;

import com.example.tourtravel.Entity.Customer;
import com.example.tourtravel.Entity.Destinations;
import com.example.tourtravel.Pojo.CustomerPojo;
import com.example.tourtravel.Pojo.DestinationPojo;

import java.util.List;
import java.util.Optional;

public interface DestinationService {
    void addDestination(DestinationPojo destinationPojo);

    void deleteById(Long id);

    List<Destinations> getAll();

    Optional<Destinations> findById(Long id);
    void updateData(Long id, DestinationPojo destinationPojo);
    boolean existsById(Long id);
}
