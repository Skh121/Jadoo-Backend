package com.example.tourtravel.Service.Impl;
import com.example.tourtravel.Entity.Destinations;
import com.example.tourtravel.Pojo.DestinationPojo;
import com.example.tourtravel.Repo.DestinationRepo;
import com.example.tourtravel.Service.DestinationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@RequiredArgsConstructor

@Service
public class DestinationServiceImpl implements DestinationService {
    private final DestinationRepo destinationRepo;

    @Override
    public void addDestination(DestinationPojo destinationPojo) {
        Destinations destinations=new Destinations();
        destinations.setDestinationName(destinationPojo.getDestinationName());
        destinations.setPrice(destinationPojo.getPrice());
        destinations.setDetails(destinations.getDetails());
        destinations.setFileData(destinationPojo.getFileData());
        destinationRepo.save(destinations);
    }

    @Override
    public void deleteById(Long id) {
        destinationRepo.deleteById(id);

    }

    @Override
    public List<Destinations> getAll() {
        return destinationRepo.findAll();
    }

    @Override
    public Optional<Destinations> findById(Long id) {
        return destinationRepo.findById(id);
    }

    @Override
    public void updateData(Long id, DestinationPojo destinationPojo) {
        Optional<Destinations> destinationOptional = destinationRepo.findById(id);
        if (destinationOptional.isPresent()) {
            Destinations existingDestination = destinationOptional.get();

            updateCustomerProperties(existingDestination, destinationPojo);
            destinationRepo.save(existingDestination); // Save the updated student
        } else {
            // Handle the case where the student with the given ID does not exist
            throw new IllegalArgumentException("Student with ID " + id + " not found");
        }

    }

    private void updateCustomerProperties(Destinations destinations, DestinationPojo destinationPojo) {
        destinations.setDestinationName(destinationPojo.getDestinationName());
        destinations.setPrice(destinationPojo.getPrice());
        destinations.setDetails(destinations.getDetails());
        destinations.setFileData(destinationPojo.getFileData());
        destinationRepo.save(destinations);
    }

    @Override
    public boolean existsById(Long id) {
        return destinationRepo.existsById(id);
    }
}
