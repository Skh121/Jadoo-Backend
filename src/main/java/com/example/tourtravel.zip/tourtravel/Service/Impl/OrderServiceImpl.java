package com.example.tourtravel.Service.Impl;


import com.example.tourtravel.Entity.Orders;
import com.example.tourtravel.Pojo.OrderPojo;
import com.example.tourtravel.Repo.OrderRepo;
import com.example.tourtravel.Service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor

public class OrderServiceImpl implements OrderService {
    private final OrderRepo orderRepo;
    @Override
    public void addOrder(OrderPojo orderPojo) {
        Orders order = new Orders();
        order.setId(orderPojo.getId());
        order.setOrderDate(orderPojo.getOrderDate());
        order.setDestinations(orderPojo.getDestinations());
        order.setCustomer(orderPojo.getCustomer());
        this.orderRepo.save(order);
    }

    @Override
    public void updateData(Integer id, OrderPojo orderPojo) {
        Optional<Orders> orderOptional = orderRepo.findById(id);
        if (orderOptional.isPresent()) {
            Orders existingOrder = orderOptional.get();
            updateOrderProperties(existingOrder, orderPojo);
            orderRepo.save(existingOrder); // Save the updated student
        } else {
            throw new IllegalArgumentException("Booking with ID " + id + " not found");
        }

    }
    private void updateOrderProperties(Orders order, OrderPojo orderPojo) {
        order.setId(orderPojo.getId());
        order.setOrderDate(orderPojo.getOrderDate());
        order.setDestinations(orderPojo.getDestinations());
        order.setCustomer(orderPojo.getCustomer());
        this.orderRepo.save(order);

    }

    @Override
    public void deleteById(Integer id) {
        orderRepo.deleteById(id);

    }

    @Override
    public List<Orders> getAll() {
        return orderRepo.findAll();
    }

    @Override
    public Optional<Orders> findById(Integer id) {
        return orderRepo.findById(id);
    }

    @Override
    public boolean existsById(Integer id) {
        return this.orderRepo.existsById(id);
    }
}
