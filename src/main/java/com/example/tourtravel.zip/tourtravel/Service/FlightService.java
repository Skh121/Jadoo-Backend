package com.example.tourtravel.Service;

import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Entity.Flights;
import com.example.tourtravel.Pojo.CompanyPojo;
import com.example.tourtravel.Pojo.FlightPojo;

import java.util.List;
import java.util.Optional;

public interface FlightService {
    void addFlights(FlightPojo flightPojo);

    void deleteById(Long id);

    List<Flights> getAll();

    Optional<Flights> findById(Long id);
    void updateData(Long id, FlightPojo flightPojo);
    boolean existsById(Long id);
}
