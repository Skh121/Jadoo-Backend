package com.example.tourtravel.Service;


import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Pojo.CompanyPojo;

import java.util.List;
import java.util.Optional;

public interface CompanyService {

    void addCompany(CompanyPojo companyPojo);

    void deleteById(Integer id);

    List<Company> getAll();

    Optional<Company> findById(Integer id);
    void updateData(Integer id, CompanyPojo companyPojo);
    boolean existsById(Integer id);
}
