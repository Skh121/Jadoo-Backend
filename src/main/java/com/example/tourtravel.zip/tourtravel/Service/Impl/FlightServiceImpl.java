package com.example.tourtravel.Service.Impl;

import com.example.tourtravel.Entity.Choices;
import com.example.tourtravel.Entity.FileData;
import com.example.tourtravel.Entity.Flights;
import com.example.tourtravel.Pojo.FlightPojo;
import com.example.tourtravel.Repo.FlightRepo;
import com.example.tourtravel.Service.FlightService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@RequiredArgsConstructor

@Service
public class FlightServiceImpl implements FlightService {
    private final FlightRepo flightRepo;
    @Override
    public void addFlights(FlightPojo flightPojo) {
        Flights flights=new Flights();
        flights.setDestination(flightPojo.getDestination());
        flights.setSource(flightPojo.getSource());
        flights.setDate(flightPojo.getDate());
        flights.setPrice(flightPojo.getPrice());
        flights.setAirport(flightPojo.getAirport());
        flightRepo.save(flights);

    }

    @Override
    public void deleteById(Long id) {
        flightRepo.deleteById(id);

    }

    @Override
    public List<Flights> getAll() {
        return flightRepo.findAll();
    }

    @Override
    public Optional<Flights> findById(Long id) {
        return flightRepo.findById(id);
    }

    @Override
    public void updateData(Long id, FlightPojo flightPojo) {
        Optional<Flights> flightOptional = flightRepo.findById(id);
        if (flightOptional.isPresent()) {
            Flights existingFlight = flightOptional.get();
            updateFlightProperties(existingFlight, flightPojo);
            flightRepo.save(existingFlight); // Save the updated student
        } else {
            throw new IllegalArgumentException("flight with ID " + id + " not found");
        }

    }
    public void updateFlightProperties(Flights flights,FlightPojo flightPojo){
        flights.setDestination(flightPojo.getDestination());
        flights.setSource(flightPojo.getSource());
        flights.setDate(flightPojo.getDate());
        flights.setPrice(flightPojo.getPrice());
        flights.setAirport(flightPojo.getAirport());
        flightRepo.save(flights);
    }

    @Override
    public boolean existsById(Long id) {
        return flightRepo.existsById(id);
    }
}
