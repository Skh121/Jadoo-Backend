package com.example.tourtravel.Service;


import com.example.tourtravel.Entity.Orders;
import com.example.tourtravel.Pojo.OrderPojo;

import java.util.List;
import java.util.Optional;

public interface OrderService {
    void addOrder(OrderPojo orderPojo);

    void deleteById(Integer id);
    List<Orders> getAll();
    Optional<Orders> findById(Integer id);
    void updateData(Integer id, OrderPojo orderPojo);
    boolean existsById(Integer id);
}
