package com.example.tourtravel.Service;

import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Entity.Hotels;
import com.example.tourtravel.Pojo.CompanyPojo;
import com.example.tourtravel.Pojo.HotelPojo;

import java.util.List;
import java.util.Optional;

public interface HotelService {
    void addHotel(HotelPojo hotelPojo);

    void deleteById(Long id);

    List<Hotels> getAll();

    Optional<Hotels> findById(Long id);
    void updateData(Long id, HotelPojo hotelPojo);
    boolean existsById(Long id);
}
