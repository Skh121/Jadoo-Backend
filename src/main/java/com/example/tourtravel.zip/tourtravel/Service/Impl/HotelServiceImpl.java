package com.example.tourtravel.Service.Impl;

import com.example.tourtravel.Entity.Flights;
import com.example.tourtravel.Entity.Hotels;
import com.example.tourtravel.Pojo.FlightPojo;
import com.example.tourtravel.Pojo.HotelPojo;
import com.example.tourtravel.Repo.HotelRepo;
import com.example.tourtravel.Service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
@RequiredArgsConstructor
public class HotelServiceImpl implements HotelService {
    private final HotelRepo hotelRepo;
    @Override
    public void addHotel(HotelPojo hotelPojo) {
        Hotels hotels=new Hotels();
        hotels.setHotel(hotelPojo.getHotel());
        hotels.setLocation(hotelPojo.getLocation());
        hotels.setDate(hotelPojo.getDate());
        hotels.setPrice(hotelPojo.getPrice());
        hotels.setNoOfDays(hotelPojo.getNoOfDays());
        hotelRepo.save(hotels);

    }

    @Override
    public void deleteById(Long id) {
        hotelRepo.deleteById(id);

    }

    @Override
    public List<Hotels> getAll() {
        return hotelRepo.findAll();
    }

    @Override
    public Optional<Hotels> findById(Long id) {
        return hotelRepo.findById(id);
    }

    @Override
    public void updateData(Long id, HotelPojo hotelPojo) {
        Optional<Hotels> hotelOptional = hotelRepo.findById(id);
        if (hotelOptional.isPresent()) {
            Hotels existingHotel = hotelOptional.get();
            updateHotelProperties(existingHotel, hotelPojo);
            hotelRepo.save(existingHotel); // Save the updated student
        } else {
            throw new IllegalArgumentException("flight with ID " + id + " not found");
        }
    }

    public void updateHotelProperties(Hotels hotels, HotelPojo hotelPojo){
        hotels.setHotel(hotelPojo.getHotel());
        hotels.setLocation(hotelPojo.getLocation());
        hotels.setDate(hotelPojo.getDate());
        hotels.setPrice(hotelPojo.getPrice());
        hotels.setNoOfDays(hotelPojo.getNoOfDays());
        hotelRepo.save(hotels);
    }
    @Override
    public boolean existsById(Long id) {
        return hotelRepo.existsById(id);
    }
}
