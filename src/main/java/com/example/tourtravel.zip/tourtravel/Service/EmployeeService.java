package com.example.tourtravel.Service;

import com.example.tourtravel.Entity.Employee;
import com.example.tourtravel.Pojo.EmployeePojo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EmployeeService {
    void addEmployee(EmployeePojo employeePojo);

    void deleteById(Integer id);

    List<Employee> getAll();

    Optional<Employee> findById(Integer id);
    void updateData(Integer id, EmployeePojo employeePojo);
    boolean existsById(Integer id);
}
