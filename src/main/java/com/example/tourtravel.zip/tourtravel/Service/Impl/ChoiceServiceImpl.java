package com.example.tourtravel.Service.Impl;

import com.example.tourtravel.Entity.Choices;
import com.example.tourtravel.Entity.Company;
import com.example.tourtravel.Pojo.ChoicePojo;
import com.example.tourtravel.Pojo.CompanyPojo;
import com.example.tourtravel.Repo.ChoiceRepo;
import com.example.tourtravel.Service.ChoiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
@RequiredArgsConstructor

public class ChoiceServiceImpl  implements ChoiceService {
    private final ChoiceRepo choiceRepo;
    @Override
    public void addChoice(ChoicePojo choicePojo) {
        Choices choices=new Choices();
        choices.setChoiceName(choicePojo.getChoiceName());
        choices.setDestinationsList(choicePojo.getDestinationsList());
       choiceRepo.save(choices);
    }

    @Override
    public void deleteById(Long id) {
        choiceRepo.deleteById(id);

    }

    @Override
    public List<Choices> getAll() {
        return choiceRepo.findAll();
    }

    @Override
    public Optional<Choices> findById(Integer id) {
        return choiceRepo.findById(id.longValue());
    }

    public void updateData(Long id, ChoicePojo choicePojo) {
        Optional<Choices> choiceOptional = choiceRepo.findById(id);
        if (choiceOptional.isPresent()) {
            Choices existingChoice = choiceOptional.get();
            updateChoiceProperties(existingChoice, choicePojo);
            choiceRepo.save(existingChoice); // Save the updated student
        } else {
            throw new IllegalArgumentException("choice with ID " + id + " not found");
        }

    }
    private void updateChoiceProperties(Choices choices, ChoicePojo choicePojo) {

        choices.setChoiceName(choicePojo.getChoiceName());
        choices.setDestinationsList(choicePojo.getDestinationsList());
        choiceRepo.save(choices);
    }

    @Override
    public boolean existsById(Long id) {
        return choiceRepo.existsById(id);
    }
}
