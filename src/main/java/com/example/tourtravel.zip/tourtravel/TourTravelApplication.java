package com.example.tourtravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourTravelApplication {

    public static void main(String[] args) {
        SpringApplication.run(TourTravelApplication.class, args);
    }

}
